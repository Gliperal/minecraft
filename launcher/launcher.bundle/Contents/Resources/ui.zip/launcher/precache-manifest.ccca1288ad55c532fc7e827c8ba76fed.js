self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "138557d5821abd5d64d10fa1b959e6f4",
    "url": "/index.html"
  },
  {
    "revision": "d1979484ec692f4b939e",
    "url": "/static/css/main.ff06d3f5.chunk.css"
  },
  {
    "revision": "5937c7cf0540f17e5fc1",
    "url": "/static/js/10.f0ba8e54.chunk.js"
  },
  {
    "revision": "db28fdafd1be19dc20ee",
    "url": "/static/js/100.cacd0ac1.chunk.js"
  },
  {
    "revision": "cc60cbc12e3a0ede9e5b",
    "url": "/static/js/101.1da05106.chunk.js"
  },
  {
    "revision": "95b6ee0d15734bc598a7",
    "url": "/static/js/102.10f61262.chunk.js"
  },
  {
    "revision": "5550a24335f4e9a2d2b9",
    "url": "/static/js/103.831c59eb.chunk.js"
  },
  {
    "revision": "5ed7aeaf8ff2e77cc7d4",
    "url": "/static/js/104.70c9ed80.chunk.js"
  },
  {
    "revision": "32e813c770862ce77629",
    "url": "/static/js/105.a8a84d9c.chunk.js"
  },
  {
    "revision": "f4eb91c91112113d8a4e",
    "url": "/static/js/106.b7fac387.chunk.js"
  },
  {
    "revision": "92a70694cbcf781bf43a",
    "url": "/static/js/107.739b49bc.chunk.js"
  },
  {
    "revision": "0035cfec2f47d5ad670a",
    "url": "/static/js/108.dcef82ff.chunk.js"
  },
  {
    "revision": "862c9c31e009d28bc385",
    "url": "/static/js/109.ac014edf.chunk.js"
  },
  {
    "revision": "e261f093577656af104e",
    "url": "/static/js/11.0edbe55d.chunk.js"
  },
  {
    "revision": "774df01d73e243bf0cf9",
    "url": "/static/js/110.e82b4e95.chunk.js"
  },
  {
    "revision": "a61a2e3fa922148af499",
    "url": "/static/js/111.dcb29f34.chunk.js"
  },
  {
    "revision": "f4d978f71ac7218bb451",
    "url": "/static/js/112.04642997.chunk.js"
  },
  {
    "revision": "790f55850619692bed8f",
    "url": "/static/js/113.d37b2d9e.chunk.js"
  },
  {
    "revision": "fff41838ebcab991aa1b",
    "url": "/static/js/114.2e056a0b.chunk.js"
  },
  {
    "revision": "f40d1b7398ac82060a72",
    "url": "/static/js/115.01048f64.chunk.js"
  },
  {
    "revision": "b6e640705a9797dd3a34",
    "url": "/static/js/116.ee8ae0ec.chunk.js"
  },
  {
    "revision": "916c7c2fd923e19d3427",
    "url": "/static/js/117.5b425ab7.chunk.js"
  },
  {
    "revision": "0ba1648fb30d8354b0ff",
    "url": "/static/js/118.5239f825.chunk.js"
  },
  {
    "revision": "6079afaf030833b748c6",
    "url": "/static/js/119.f6cd566f.chunk.js"
  },
  {
    "revision": "678fd6b4e61bf9433a21",
    "url": "/static/js/12.62464281.chunk.js"
  },
  {
    "revision": "9960edb09f00410ae043",
    "url": "/static/js/120.a51be5c1.chunk.js"
  },
  {
    "revision": "ba9306582b0e2081e57f",
    "url": "/static/js/121.e6db28be.chunk.js"
  },
  {
    "revision": "0098096280c6efebad05",
    "url": "/static/js/122.65c1b872.chunk.js"
  },
  {
    "revision": "14867428ddbbe9db364c",
    "url": "/static/js/123.86088a62.chunk.js"
  },
  {
    "revision": "1615bc384ad07864582f",
    "url": "/static/js/124.b1e2d4d3.chunk.js"
  },
  {
    "revision": "6e80861ecb8f74afdb78",
    "url": "/static/js/125.e7f5dcc2.chunk.js"
  },
  {
    "revision": "9f170eb23648f62ece68",
    "url": "/static/js/126.271751b4.chunk.js"
  },
  {
    "revision": "e1e0ea3bba85cdb39b66",
    "url": "/static/js/127.fad7a340.chunk.js"
  },
  {
    "revision": "233e9abeaa12b42a4f60",
    "url": "/static/js/128.de5cb3be.chunk.js"
  },
  {
    "revision": "d008a1c47eb55e98cf22",
    "url": "/static/js/129.ddcc3daa.chunk.js"
  },
  {
    "revision": "1529908a9d919c897560",
    "url": "/static/js/13.60122445.chunk.js"
  },
  {
    "revision": "b56c5f92c46dbd58f33a",
    "url": "/static/js/130.c15f1061.chunk.js"
  },
  {
    "revision": "005367314416357441a4",
    "url": "/static/js/14.15890a4e.chunk.js"
  },
  {
    "revision": "46b425d1e31bb73afb2b",
    "url": "/static/js/15.e9d58788.chunk.js"
  },
  {
    "revision": "e3c3acf1e8009b3f9100",
    "url": "/static/js/16.533df3a0.chunk.js"
  },
  {
    "revision": "6a6dd1be0f76486bcdf3",
    "url": "/static/js/17.9a3d4acf.chunk.js"
  },
  {
    "revision": "1b3e1b2ec940dfb0d19a",
    "url": "/static/js/18.92566bec.chunk.js"
  },
  {
    "revision": "a6828e115e904dfba965",
    "url": "/static/js/19.4f6da369.chunk.js"
  },
  {
    "revision": "16ac1ad4ce719fc9afd9",
    "url": "/static/js/2.9303ea89.chunk.js"
  },
  {
    "revision": "d6e79fe6b12b95de4f05",
    "url": "/static/js/20.7461fff4.chunk.js"
  },
  {
    "revision": "3bad5cb9f4e3946f545e",
    "url": "/static/js/21.3c741325.chunk.js"
  },
  {
    "revision": "7f9c334c115a0073d5b5",
    "url": "/static/js/22.fe9ec63c.chunk.js"
  },
  {
    "revision": "9ddd57e35a2aec83b260",
    "url": "/static/js/23.72403e3c.chunk.js"
  },
  {
    "revision": "0e8c341b2ae4525ac453",
    "url": "/static/js/24.0ec299c3.chunk.js"
  },
  {
    "revision": "d29295f70edfda337b65",
    "url": "/static/js/25.c00188a2.chunk.js"
  },
  {
    "revision": "d1902b1d38269522cbf7",
    "url": "/static/js/26.c73b4b25.chunk.js"
  },
  {
    "revision": "929c4588b95746194d28",
    "url": "/static/js/27.6230436d.chunk.js"
  },
  {
    "revision": "093549bd5df995309ffb",
    "url": "/static/js/28.39f43aa7.chunk.js"
  },
  {
    "revision": "79dafb7eec56e470ce38",
    "url": "/static/js/29.b1dbd852.chunk.js"
  },
  {
    "revision": "59f64679558d7a23c116",
    "url": "/static/js/3.388ceead.chunk.js"
  },
  {
    "revision": "e431e4dbb46769d3f7fb",
    "url": "/static/js/30.2d73c8ae.chunk.js"
  },
  {
    "revision": "e139d932460d1c692b56",
    "url": "/static/js/31.50efad13.chunk.js"
  },
  {
    "revision": "1bef3c233da67cdada74",
    "url": "/static/js/32.ec1742ce.chunk.js"
  },
  {
    "revision": "d1ddeb8c3553508f6e4d",
    "url": "/static/js/33.133e7e45.chunk.js"
  },
  {
    "revision": "0dbaf734703e7d548158",
    "url": "/static/js/34.0fdfc118.chunk.js"
  },
  {
    "revision": "aff832752a1fa951dd42",
    "url": "/static/js/35.7d1a8579.chunk.js"
  },
  {
    "revision": "42e1e6d952d476c9a686",
    "url": "/static/js/36.ea241860.chunk.js"
  },
  {
    "revision": "7a426592551e0615887c",
    "url": "/static/js/37.bbf104c1.chunk.js"
  },
  {
    "revision": "8dc8b5a28b432de0c136",
    "url": "/static/js/38.b6a772f9.chunk.js"
  },
  {
    "revision": "aa386432488d3d39090c",
    "url": "/static/js/39.7902829b.chunk.js"
  },
  {
    "revision": "a8ef53e59cd8897cfd88",
    "url": "/static/js/4.0d4c42ca.chunk.js"
  },
  {
    "revision": "024a9d9e634c0cce660b",
    "url": "/static/js/40.74ae25ab.chunk.js"
  },
  {
    "revision": "dd8427a343f53cc6cc2a",
    "url": "/static/js/41.fa4acce0.chunk.js"
  },
  {
    "revision": "de3e37208409514b5d4b",
    "url": "/static/js/42.553f14be.chunk.js"
  },
  {
    "revision": "f23e9b7c2e721ec20f72",
    "url": "/static/js/43.d206cbf6.chunk.js"
  },
  {
    "revision": "a14eadbebc2ad936126b",
    "url": "/static/js/44.5d714e41.chunk.js"
  },
  {
    "revision": "06efa77b8c39f3f49a96",
    "url": "/static/js/45.92065a17.chunk.js"
  },
  {
    "revision": "83fbf1fb88bc830ccc24",
    "url": "/static/js/46.04912c7a.chunk.js"
  },
  {
    "revision": "4a26f03e5328b7b79ebd",
    "url": "/static/js/47.d9329bb1.chunk.js"
  },
  {
    "revision": "8ae7a97ab0f2da7f78af",
    "url": "/static/js/48.b775b546.chunk.js"
  },
  {
    "revision": "3cc46e41ee9279f96209",
    "url": "/static/js/49.5e0cdc9f.chunk.js"
  },
  {
    "revision": "126c7cfdd04da7303471",
    "url": "/static/js/5.c2f46b8f.chunk.js"
  },
  {
    "revision": "b6964f20894d8aad61c8",
    "url": "/static/js/50.391768cb.chunk.js"
  },
  {
    "revision": "3cafbae59b32431330cb",
    "url": "/static/js/51.b6fd65ad.chunk.js"
  },
  {
    "revision": "49e5900099086e84cd2c",
    "url": "/static/js/52.3e27fb74.chunk.js"
  },
  {
    "revision": "5c1b9df2c35dfbefc87d",
    "url": "/static/js/53.90f8ef60.chunk.js"
  },
  {
    "revision": "45b3ed91b470bbbfb733",
    "url": "/static/js/54.e9df5d5f.chunk.js"
  },
  {
    "revision": "9cc2a0940715b98d4c65",
    "url": "/static/js/55.d42cc573.chunk.js"
  },
  {
    "revision": "c74a69e6dd7f014dbe9c",
    "url": "/static/js/56.9408134e.chunk.js"
  },
  {
    "revision": "dc1088ab96b800800d2a",
    "url": "/static/js/57.3f8b4d66.chunk.js"
  },
  {
    "revision": "2f840ddec9f3ad9a8cf1",
    "url": "/static/js/58.e2a7ec9a.chunk.js"
  },
  {
    "revision": "2443a96d6c49b139d593",
    "url": "/static/js/59.09fb6555.chunk.js"
  },
  {
    "revision": "6c34ce9819c21cad1797",
    "url": "/static/js/6.9ec18e56.chunk.js"
  },
  {
    "revision": "25827bbae69a178db7e2",
    "url": "/static/js/60.df994eb2.chunk.js"
  },
  {
    "revision": "230e4a0c6130f06421c2",
    "url": "/static/js/61.69a426e4.chunk.js"
  },
  {
    "revision": "c8e77fba6c2e59b16db9",
    "url": "/static/js/62.ea07607b.chunk.js"
  },
  {
    "revision": "30e82220c457bca395a1",
    "url": "/static/js/63.c27b73ef.chunk.js"
  },
  {
    "revision": "e905947a7f8859427a1c",
    "url": "/static/js/64.1e098b01.chunk.js"
  },
  {
    "revision": "a7838e5e6bbe2442f50f",
    "url": "/static/js/65.187a5538.chunk.js"
  },
  {
    "revision": "091be0427cc115dda46e",
    "url": "/static/js/66.4a87c344.chunk.js"
  },
  {
    "revision": "ec4df9c3211fbb68b64c",
    "url": "/static/js/67.65168855.chunk.js"
  },
  {
    "revision": "c46988b036a51726b7f9",
    "url": "/static/js/68.ff099f72.chunk.js"
  },
  {
    "revision": "8e2760b4d3c22b7524a2",
    "url": "/static/js/69.44e01092.chunk.js"
  },
  {
    "revision": "df3c2ac1ac6572a915b7",
    "url": "/static/js/7.eea1c49e.chunk.js"
  },
  {
    "revision": "72a45d317a309233aad8",
    "url": "/static/js/70.61825791.chunk.js"
  },
  {
    "revision": "3f082f7a0f5980646cc9",
    "url": "/static/js/71.c02576bb.chunk.js"
  },
  {
    "revision": "603ea91c00aec5735e53",
    "url": "/static/js/72.5312d211.chunk.js"
  },
  {
    "revision": "243258750c9c0259cf17",
    "url": "/static/js/73.de8aaaf3.chunk.js"
  },
  {
    "revision": "9c8085dd79a8988ab426",
    "url": "/static/js/74.a5c3cdb5.chunk.js"
  },
  {
    "revision": "777130a31961b8018b53",
    "url": "/static/js/75.2a0a7379.chunk.js"
  },
  {
    "revision": "25699d39bd0bc11f8d94",
    "url": "/static/js/76.fa278129.chunk.js"
  },
  {
    "revision": "d9cddf0fcf494ca109c8",
    "url": "/static/js/77.7cca2483.chunk.js"
  },
  {
    "revision": "538b4c89ac904d83f74f",
    "url": "/static/js/78.d837f9a9.chunk.js"
  },
  {
    "revision": "511100dad4c0db1e8d4b",
    "url": "/static/js/79.c08c2834.chunk.js"
  },
  {
    "revision": "3930c2f7abd0ab92150d",
    "url": "/static/js/8.637c3946.chunk.js"
  },
  {
    "revision": "e969e5bdf89c3ddc4704",
    "url": "/static/js/80.e5d39926.chunk.js"
  },
  {
    "revision": "0f0d273d33417b14313b",
    "url": "/static/js/81.2e44ce37.chunk.js"
  },
  {
    "revision": "ab26be646e6a2087f570",
    "url": "/static/js/82.af3253c9.chunk.js"
  },
  {
    "revision": "3894c1d15ef617ecbbda",
    "url": "/static/js/83.eef10071.chunk.js"
  },
  {
    "revision": "5cedc78e51b01934b7a9",
    "url": "/static/js/84.95156f47.chunk.js"
  },
  {
    "revision": "58161046fda7a0d257c9",
    "url": "/static/js/85.d49e7823.chunk.js"
  },
  {
    "revision": "07d4005be265540d71e8",
    "url": "/static/js/86.13b2a10b.chunk.js"
  },
  {
    "revision": "a198944fa6991a949fa9",
    "url": "/static/js/87.203a1dc0.chunk.js"
  },
  {
    "revision": "8d1ba3fc97ecb7c998d1",
    "url": "/static/js/88.b9eb7ee7.chunk.js"
  },
  {
    "revision": "24070ef2cf2e57aac0b4",
    "url": "/static/js/89.d312bd57.chunk.js"
  },
  {
    "revision": "35116ae96c24e2d2913f",
    "url": "/static/js/9.feaae625.chunk.js"
  },
  {
    "revision": "ddb814669049b7d3e9e6",
    "url": "/static/js/90.159c8d89.chunk.js"
  },
  {
    "revision": "4ea6d467c09bca8606f1",
    "url": "/static/js/91.0680a5de.chunk.js"
  },
  {
    "revision": "9b8624fc4120a4249f09",
    "url": "/static/js/92.3eb65ac5.chunk.js"
  },
  {
    "revision": "c1c9c97dec1aa08ccd2a",
    "url": "/static/js/93.f5c8fd90.chunk.js"
  },
  {
    "revision": "8c7d17ed747e415f985b",
    "url": "/static/js/94.d3865758.chunk.js"
  },
  {
    "revision": "14115cedd33e85c05f7f",
    "url": "/static/js/95.bea71066.chunk.js"
  },
  {
    "revision": "0637d2963454d2e65a1a",
    "url": "/static/js/96.961f74df.chunk.js"
  },
  {
    "revision": "59322687c99c6f72f0e2",
    "url": "/static/js/97.b3df4ad1.chunk.js"
  },
  {
    "revision": "068850df5b051613dc88",
    "url": "/static/js/98.3f9f002e.chunk.js"
  },
  {
    "revision": "ef26fe559582cc8bddf0",
    "url": "/static/js/99.e2f6aec9.chunk.js"
  },
  {
    "revision": "d1979484ec692f4b939e",
    "url": "/static/js/main.19487097.chunk.js"
  },
  {
    "revision": "7cc5d1b4268131b9b9f4",
    "url": "/static/js/runtime~main.68ac5fbb.js"
  },
  {
    "revision": "ff17faa7f6f3389a1ff24941cce00c36",
    "url": "/static/media/Minecraft-Ten.ff17faa7.woff2"
  },
  {
    "revision": "d594fbec5f450765e1738e6624dbad81",
    "url": "/static/media/NotoSans-Bold.d594fbec.woff2"
  },
  {
    "revision": "d0bba9a6b223bb94834ddbc49e3acc22",
    "url": "/static/media/NotoSans.d0bba9a6.woff2"
  },
  {
    "revision": "f8b5bc10a004f0894a0b519fd42758e6",
    "url": "/static/media/arrow-down.f8b5bc10.svg"
  },
  {
    "revision": "ea2e2c570f63412cfa968c5b2165bf87",
    "url": "/static/media/bg-login.ea2e2c57.jpg"
  },
  {
    "revision": "26787722b3490f0638d79464d6282ad0",
    "url": "/static/media/check.26787722.svg"
  },
  {
    "revision": "df0cf82375503905bf47154f9aaafa3d",
    "url": "/static/media/close-dark.df0cf823.svg"
  },
  {
    "revision": "53ee760110a8fa023cca96601326aafd",
    "url": "/static/media/close.53ee7601.svg"
  },
  {
    "revision": "53ee760110a8fa023cca96601326aafd",
    "url": "/static/media/discard.53ee7601.svg"
  },
  {
    "revision": "bc0317387465140c40b7667dc1cff774",
    "url": "/static/media/download-dark.bc031738.svg"
  },
  {
    "revision": "84ed37c67296b7004924eb7030a0ddec",
    "url": "/static/media/download.84ed37c6.svg"
  },
  {
    "revision": "acb4d6c7e96d1645e89206d28acbe1ae",
    "url": "/static/media/dungeons-purchased.acb4d6c7.png"
  },
  {
    "revision": "acb5f8955cd18d70296035990c353525",
    "url": "/static/media/dungeons.acb5f895.png"
  },
  {
    "revision": "4aaca68a524ef8e8e681e9e01fc0702a",
    "url": "/static/media/error.4aaca68a.svg"
  },
  {
    "revision": "c989686507298f40a9bf6e29e125de6d",
    "url": "/static/media/external.c9896865.svg"
  },
  {
    "revision": "5603c3bef0efe32e4a5a8ef48eb27786",
    "url": "/static/media/java.5603c3be.jpg"
  },
  {
    "revision": "b5432c6e1ea666e6c9d4c9079e153c48",
    "url": "/static/media/java.b5432c6e.svg"
  },
  {
    "revision": "a5232d00132780ef9db4aa8cc2ae5f0d",
    "url": "/static/media/minecraft.a5232d00.svg"
  },
  {
    "revision": "038dc20dd4ad218c3c1f252a1444c2df",
    "url": "/static/media/new.038dc20d.svg"
  },
  {
    "revision": "17f1cef2fe603ab552f63219704c6301",
    "url": "/static/media/question.17f1cef2.svg"
  },
  {
    "revision": "f52114610de250e58e125573a7f4edd3",
    "url": "/static/media/reconnect.f5211461.svg"
  },
  {
    "revision": "53ee760110a8fa023cca96601326aafd",
    "url": "/static/media/resolution-x.53ee7601.svg"
  },
  {
    "revision": "4c0eed1cb7797ccfd5db8c1229148795",
    "url": "/static/media/screen.4c0eed1c.svg"
  },
  {
    "revision": "cdc7a112a5f71c1c002e097fca3b5be7",
    "url": "/static/media/search.cdc7a112.svg"
  },
  {
    "revision": "e8f8547000cc6278281b84d62918ceba",
    "url": "/static/media/village-and-pillage.e8f85470.png"
  }
]);