self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "713557abb23c62a05e1dc88abf513d98",
    "url": "/index.html"
  },
  {
    "revision": "6244f5f07a8a7ebccb3a",
    "url": "/static/css/main.1618a713.chunk.css"
  },
  {
    "revision": "e23014cb389d2c738e7e",
    "url": "/static/js/2.759e6531.chunk.js"
  },
  {
    "revision": "6244f5f07a8a7ebccb3a",
    "url": "/static/js/main.ebd40360.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "ff17faa7f6f3389a1ff24941cce00c36",
    "url": "/static/media/Minecraft-Ten.ff17faa7.woff2"
  },
  {
    "revision": "d594fbec5f450765e1738e6624dbad81",
    "url": "/static/media/NotoSans-Bold.d594fbec.woff2"
  },
  {
    "revision": "d0bba9a6b223bb94834ddbc49e3acc22",
    "url": "/static/media/NotoSans.d0bba9a6.woff2"
  },
  {
    "revision": "f8b5bc10a004f0894a0b519fd42758e6",
    "url": "/static/media/arrow-down.f8b5bc10.svg"
  },
  {
    "revision": "26787722b3490f0638d79464d6282ad0",
    "url": "/static/media/check.26787722.svg"
  },
  {
    "revision": "df0cf82375503905bf47154f9aaafa3d",
    "url": "/static/media/close-dark.df0cf823.svg"
  },
  {
    "revision": "53ee760110a8fa023cca96601326aafd",
    "url": "/static/media/close.53ee7601.svg"
  },
  {
    "revision": "53ee760110a8fa023cca96601326aafd",
    "url": "/static/media/discard.53ee7601.svg"
  },
  {
    "revision": "4aaca68a524ef8e8e681e9e01fc0702a",
    "url": "/static/media/error.4aaca68a.svg"
  }
]);